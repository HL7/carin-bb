package http://hl7.org/fhir/us/carin-bb/ImplementationGuide/carin-bb;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class CARINBBCoverage {

}
